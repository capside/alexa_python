from __future__ import print_function
from copy import copy

import requests
import xml.etree.ElementTree as ET


distance_matrix_key='Your Google DistanceMatrix API KEY'
distance_matrix_url='https://maps.googleapis.com/maps/api/distancematrix/json?'

str_req_work='origins=Paseo%20de%20la%20chopera,208,Alcobendas,Madrid,spain&destinations=Camino%20Cerro%20de%20los%20gamos,1,pozuelo%20de%20alarcon,madrid,spain&departure_time=now&traffic_model=pessimistic&key='
str_req_home='origins=Camino%20Cerro%20de%20los%20gamos,1,pozuelo%20de%20alarcon,madrid,spain&destinations=Paseo%20de%20la%20chopera,208,Alcobendas,Madrid,spain&departure_time=now&traffic_model=pessimistic&key='

 
def lambda_handler(event, context):
    app_id = event['session']['application']['applicationId']
    tipo_req=event['request']['type']

    print("event.session.application.applicationId=" + app_id)
 
    #if (app_id != "Your Alexa APP ID"):
    #   raise ValueError("Invalid Application ID")
 
    if event['session']['new']:
        starting_session({'requestId': event['request']['requestId']},event['session'])

    if tipo_req == "LaunchRequest":
        return launch(event['request'], event['session'])
    elif tipo_req == "IntentRequest":
        return intent(event['request'], event['session'])
    elif tipo_req == "SessionEndedRequest":
        return session_end(event['request'], event['session'])
 
 
def starting_session(session_request_id, session):
    print("Session started: requestId=" + session_request_id['requestId']+", sessionId=" + session['sessionId'])
 
 
def launch(launch_request, session): 
    print("Launch requestId=" + launch_request['requestId'] + ", sessionId=" + session['sessionId'])
    return welcome()
 
 
def intent(intent_request, session):
 
    print("Intent requestId=" + intent_request['requestId'] + ", sessionId=" + session['sessionId'])
 
    intent = intent_request['intent']
    intent_name = intent_request['intent']['name']

    if intent_name == "GiveMeSomething":
        return tell_me_now(intent, session)
    elif intent_name == "AMAZON.HelpIntent":
        return welcome()
    else:
        raise ValueError("Intent does not exist")
 
 
def session_end(session_ended_request, session):
    print("Session end: requestId=" + session_ended_request['requestId'] + ", sessionId=" + session['sessionId'])
 
# ---------------skill's functions------------------
 
 
def welcome():
    session_attributes = {}
    card_title = "Start"
    speech = "Hi there. Where do you want to go?"
    re_speech = "mate, tell me home or work and I'll tell you if it is a good time to move"
    end_session = False
    return build_complete_response(session_attributes, build_response_internals(card_title, speech, re_speech, end_session))
 
 
def tell_me_now(intent, session):
 
    intencion  = intent['name']
    card_title = intent['name']
    session_attributes = {}
    end_session = True
    re_speech="tell me what I want to hear mate..."
    problemas={}

    if intencion=='Work':
        r=requests.get(distance_matrix_url+str_req_work+distance_matrix_key)
        minutes=int(round(r.json()['rows'][0]['elements'][0]['duration_in_traffic']['value']/60))
    elif intencion=='Home':
        r=requests.get(distance_matrix_url+str_req_home+distance_matrix_key)
        minutes=int(round(r.json()['rows'][0]['elements'][0]['duration_in_traffic']['value']/60))
    else:
        minutes=1000000

    if minutes<25: 
        speech="You'll be fine leaving now, estimated time is "+minutes+" minutes to "+intencion
    elif minutes < 1000000:
        mi_ruta=[['M-616',0.0,0.0],['M-607',17.0,13.0],[' M-40 ',57.0,44.0]]
        for elem in mi_ruta:
            problemas[elem[0]]=busca_atasco(elem[0],elem[1],elem[2])
        session_attributes=problemas

        string_problemas=''
        for elemento in (list(problemas.keys())):
            string_problemas=string_problemas+', '+elemento
        
        speech="Hold on, estimated time is "+minutes+" minutes to "+intencion+", there are issues on \
        these roads ,"+string_problemas+" grab a coffee and relax or die bored on the road"
    else:
        speech="You really don't want to know the time for that mate"
    

    return build_complete_response(session_attributes, build_response_internals(card_title, speech, re_speech, end_session, card_content=problemas))
 
 
# ---------------Response Builders----------------
def build_response_internals(title, speech, re_speech, end_session,card_content='Some Content'):
    return {
        'outputSpeech': {
            'type': 'PlainText',
            'text': speech
        },
        'card': {
            'type': 'Simple',
            'title': 'SessionSpeechlet - ' + title,
            'content': card_content
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': re_speech
            }
        },
        'shouldEndSession': end_session
    }
 
 
def build_complete_response(session_attributes, speech_response):
    return {
        'version': '1.0',
        'sessionAttributes': session_attributes,
        'response': speech_response
    }

# ---------------Helpers----------------
#Credit here
#https://stackoverflow.com/questions/2148119/how-to-convert-an-xml-string-to-a-dictionary-in-python
def dictify(r,root=True):
    if root:
        return {r.tag : dictify(r, False)}
    d=copy(r.attrib)
    if r.text:
        d["_text"]=r.text
    for x in r.findall("./*"):
        if x.tag not in d:
            d[x.tag]=[]
        d[x.tag].append(dictify(x,False))
    return d


def busca_atasco(my_road, my_start_km=0.0, my_end_km=0.0, atascos_list=dictify(ET.fromstring(requests.get('http://www.dgt.es/incidencias.xml').text))['raiz']['incidencia']):
    atascos=[]
    atasco_road=False
    for i in range(0,len(atascos_list)):
        road      =atascos_list[i].get('carretera', 'none')[0].get('_text','none')
        nivel     =atascos_list[i].get('nivel','none')[0].get('_text','none')
        cause     =atascos_list[i].get('causa','none')[0].get('_text','none')
        kilometer =atascos_list[i].get('pk_inicial','none')[0].get('_text','none')
        if kilometer=='none':
            kilometer_float=0.0
        else:
            kilometer_float=float(kilometer.replace(" ",""))
        
    
        if (my_start_km==0.0 or my_end_km==0.0):
            atasco_road=(' '+my_road.upper()+' '==road and nivel!=' VERDE ')
        elif (my_start_km < my_end_km):
            atasco_road=(' '+my_road.upper()+' '==road and nivel!=' VERDE ' and my_start_km >= kilometer_float >= my_end_km)
        else:
            atasco_road=(' '+my_road.upper()+' '==road and nivel!=' VERDE ' and my_end_km >= kilometer_float >= my_start_km)

        if atasco_road:
            atascos.append({'carretera':road,'nivel':nivel,'causa':cause,'kilometro':kilometer})
    return atascos